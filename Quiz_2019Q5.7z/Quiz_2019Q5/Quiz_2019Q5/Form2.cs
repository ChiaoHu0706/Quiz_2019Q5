﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZXing;
using vb = Microsoft.VisualBasic;


namespace Quiz_2019Q5
{
    public partial class Form2 : Form
    {
        Random RN = new Random();
        public Form2()
        {
            InitializeComponent();
        }

      

        private void 新增ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PictureBox PB = new PictureBox();
            this.WindowState = FormWindowState.Maximized;

            //2.Properties setting
            PB.BackColor = Color.Pink;
            PB.Top = RN.Next(10, 800);
            PB.Left = RN.Next(20, 900);
            PB.Height = RN.Next(60, 180);
            PB.Width = PB.Height;
            //3.Event Handler
            PB.Click += new EventHandler(PBC);
            //4.Add Control

            this.Controls.Add(PB);


            this.Text = "Number of Controls ：" + this.Controls.Count;

        }
        private void PBC(object sender, EventArgs e)
        {
            string Demo;
            Demo = vb.Interaction.InputBox("請輸入中文或網址", "107-5");
            try
            {
                ZXing.BarcodeWriter BW = new ZXing.BarcodeWriter
                {
                    Format = ZXing.BarcodeFormat.QR_CODE,
                    Options = new ZXing.QrCode.QrCodeEncodingOptions
                    {
                        Height = ((PictureBox)sender).Height,
                        Width = ((PictureBox)sender).Width,
                        CharacterSet = "UTF-8",//中文亂碼
                        ErrorCorrection = ZXing.QrCode.Internal.ErrorCorrectionLevel.H
                    }
                };
                ((PictureBox)sender).Image = BW.Write(Demo);// 文字轉QRCODE
                this.Text = "Number of Controls ：" + this.Controls.Count;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void 移除ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool HaveTB = true;//Have any TextBox in this from?(有任何的Textbox在這form?)
            while (HaveTB)
            {
                foreach (Control ctrl in this.Controls)
                {
                    HaveTB = false;
                    //if (ctrl.GetType() == typeof(TextBox)||ctrl.GetType()==typeof(PictureBox)|| ctrl.GetType() == typeof(Button))   把button textbox picturebox移除
                    if (ctrl.GetType() != typeof(MenuStrip))   //除了Menustrip以外其他全部移除
                    {
                        this.Controls.Remove(ctrl);
                        HaveTB = true;
                    }
                }
            }
            this.Text = "Number of Controls ：" + this.Controls.Count;
        }
    }
}
