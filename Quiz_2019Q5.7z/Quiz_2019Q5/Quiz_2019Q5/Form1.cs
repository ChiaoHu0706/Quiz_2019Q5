﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Quiz_2019Q5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int Rainbow = 0;
        bool X = true;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        X = true;
                        break;
                    case 1:
                        X = false;
                        break;


                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "提示訊息", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            switch (Rainbow)
            {
                case 0:
                    groupBox1.Text = "紅(Red)";
                    groupBox1.BackColor = Color.Red;
                    break;
                case 1:
                    groupBox1.Text = "澄(Orange)";
                    groupBox1.BackColor = Color.Orange;
                    break;
                case 2:
                    groupBox1.Text = "黃(Yellow)";
                    groupBox1.BackColor = Color.Yellow;
                    break;
                case 3:
                    groupBox1.Text = "綠(Green)";
                    groupBox1.BackColor = Color.Green;
                    break;
                case 4:
                    groupBox1.Text = "藍(Blue)";
                    groupBox1.BackColor = Color.Blue;
                    break;
                case 5:
                    groupBox1.Text = "靛(Indigo)";
                    groupBox1.BackColor = Color.Indigo;
                    break;
                case 6:
                    groupBox1.Text = "紫(Purple)";
                    groupBox1.BackColor = Color.Purple;
                    break;
            }

            if (X == true)
            {
                Rainbow++;
                if (Rainbow > 6)
                {
                    Rainbow = 0;
                }
            }
            if (X == false)
            {
                Rainbow--;
                if (Rainbow < 0)
                {
                    Rainbow = 6;
                }
            }
        }

        private void Form1_DoubleClick(object sender, EventArgs e)
        {
      
                Form2 f = new Form2();

                f.ShowDialog();
            
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            timer1.Interval = vScrollBar1.Value;
            this.Text = "間隔" + Math.Round((double)vScrollBar1.Value / 1000, 2).ToString() + "秒";
        }
    }
}
